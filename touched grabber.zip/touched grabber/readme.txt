Extract to folder first before running.

https://discord.gg/y7bpsMrjv2